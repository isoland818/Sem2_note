package ed.inf.adbs.minibase.base;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;


public class SelectOperator implements Operator{

    private Operator child;
    private List<ComparisonAtom> conditions;
    private HashMap<String, Integer> reference;

    private List<Tuple> tuples;

    private Iterator<Tuple> selectIterator;

    public SelectOperator(Operator child, List<ComparisonAtom> conditions) {
        this.child=child;
        this.conditions=conditions;
        this.reference=child.getReference();
        parseCondition();
        selectTuples();
        this.selectIterator=tuples.listIterator();
    }

    @Override
    public HashMap<String, Integer> getReference() {
        return reference;
    }

    @Override
    public Tuple getNextTuple() {
        if(selectIterator.hasNext()){
            return selectIterator.next();
        }
        return null;
    }

    private void selectTuples(){
        tuples=new ArrayList<>();
        Tuple tuple;
        while((tuple=child.getNextTuple())!=null){
            System.out.println(reference);
            System.out.println(conditions);
            if(Predicate.check(tuple, conditions, reference)){
                tuples.add(tuple);
            }
        }
    }

    private void parseCondition(){
        RelationalAtom atom = ((ScanOperator) child).getAtom();
        List<Term> terms = atom.getTerms();
        for(int i=0; i<terms.size(); i++) {
            if(!terms.get(i).isVariable()){
                Variable sub = generateVar(3);
                ComparisonAtom newCondition = new ComparisonAtom(sub, terms.get(i), ComparisonOperator.EQ);
                conditions.add(newCondition);
                reference.remove(terms.get(i).toString());
                atom.setTerm(i, sub);
                reference.put(sub.getName(), i);
            }
        }
    }

    @Override
    public void reset() {
        this.selectIterator= tuples.listIterator();
    }

    @Override
    public void dump() {

    }

    static Variable generateVar(int length) {
        String[] chars = {"a", "b", "c", "x", "y", "z"};
        String varName = "";
        for (int i = 0; i < length; i++) {
            int index = (int) (Math.random()*6);
            varName+=chars[index];
        }
        return new Variable(varName);
    }
}
