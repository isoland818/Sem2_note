package ed.inf.adbs.minibase.base;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ProjectionOperator implements Operator{
    private Operator child;
    private HashMap<String, Integer> reference;
    private List<Variable> queryVar;

    public ProjectionOperator(Operator child, List<Variable> queryVar){
        this.child=child;
        this.reference=child.getReference();
        this.queryVar=queryVar;

    }

    @Override
    public HashMap<String, Integer> getReference() {
        return reference;
    }

    @Override
    public Tuple getNextTuple() {
        Tuple tuple;
        while((tuple=child.getNextTuple())!=null){
            List<Object> value = new ArrayList<>();
            for(Variable var: queryVar){
                value.add(tuple.getValue().get(reference.get(var.getName())));
            }
            return new Tuple(value);
        }
        return null;
    }

    @Override
    public void reset() {
        child.reset();
    }

    @Override
    public void dump() {

    }
}
