package ed.inf.adbs.minibase.base;

import java.util.HashMap;

public interface Operator {
    Tuple getNextTuple();

    void reset();

    void dump();

    HashMap<String, Integer> getReference();
}
