package ed.inf.adbs.minibase.base;

import java.util.*;

import static ed.inf.adbs.minibase.base.SelectOperator.generateVar;

public class QueryInterpreter {
    public static void generatePlan(Query query){
        List<Atom> body = query.getBody();
        HashMap<String, ScanOperator> scanOps = new HashMap<>();
        HashMap<String, SelectOperator> selectOps = new HashMap<>();
        HashMap<String, JoinOperator> joinOps = new HashMap<>();
        HashMap<String, String> varMap = new HashMap<>();
        HashMap<String, List<String>> subs = new HashMap<>();
        HashMap<String, List<ComparisonAtom>> selections = new HashMap<>();
        HashMap<String, List<ComparisonAtom>> joins = new HashMap<>();
        for(int i=0; i< body.size(); i++){
            Atom atom = body.get(i);
            if(atom.isRelational()){
                RelationalAtom ra = (RelationalAtom) atom;
                scanOps.put(ra.getName(), new ScanOperator(ra));
                for(Term term: ra.getTerms()){
                    if(term.isVariable()){
                        if(varMap.containsKey(term.toString())){
                            Variable sub = generateVar(5);
                            body.add(new ComparisonAtom(new Variable(term.toString()), sub, ComparisonOperator.EQ));
                            varMap.put(sub.getName(), ra.getName());
                            if(!subs.containsKey(ra.getName())){
                                subs.put(term.toString(), new ArrayList<>(Collections.singletonList(sub.getName())));
                            }else{
                                subs.get(term.toString()).add(sub.getName());
                            }
                            ((Variable) term).setName(sub.getName());
                        }else{
                            varMap.put(term.toString(), ra.getName());
                        }
                    }
                }
            }else{
                ComparisonAtom ca = (ComparisonAtom) atom;
                if(!ca.getTerm1().isVariable() && !ca.getTerm2().isVariable()){
                    if(ca.valid()){
                        continue;
                    }else{
                        return;
                    }
                }else{
                    List<String> relationInvolved = isSelection(ca, varMap);
                    System.out.println(relationInvolved);
                    if(relationInvolved.size()==1){
                        String relation = relationInvolved.get(0);
                        if(selections.containsKey(relation)){
                            selections.get(relation).add(ca);
                        }else{
                            selections.put(relation, new ArrayList<>(Collections.singletonList(ca)));
                        }
                        complementComparison(body, subs, ca);
                    }else{
                        Collections.sort(relationInvolved);
                        String join = relationInvolved.get(0)+","+relationInvolved.get(1);
                        if(!joins.containsKey(join)){
                            joins.put(join, new ArrayList<>(Collections.singletonList(ca)));
                        }else{
                            joins.get(join).add(ca);
                        }
                    }
                }
            }
        }
        generateTree(scanOps, joinOps, selectOps, selections, joins);
    }

    private static void generateTree(HashMap<String, ScanOperator> scanOps, HashMap<String, JoinOperator> joinOps, HashMap<String, SelectOperator> selectOps,
                                     HashMap<String, List<ComparisonAtom>> selections, HashMap<String, List<ComparisonAtom>> joins){
        for(String select: selections.keySet()){
            selectOps.put(select, new SelectOperator(scanOps.get(select), selections.get(select)));
        }
        for(String join: joins.keySet()){
            String[] relations = join.split(",");
            Operator left = joinOps.containsKey(relations[0])? joinOps.get(relations[0]): scanOps.get(relations[0]);
            Operator right = joinOps.containsKey(relations[1])? joinOps.get(relations[1]): scanOps.get(relations[1]);
            joinOps.put(join, new JoinOperator(left, right, joins.get(join)));
        }

    }
    private static List<String> isSelection(ComparisonAtom atom, HashMap<String, String> varMap){
        List<String> relationInvolved = new ArrayList<>();
        String term1 = atom.getTerm1().toString();
        String term2 = atom.getTerm2().toString();
        String relation1 = varMap.getOrDefault(term1, null);
        String relation2 = varMap.getOrDefault(term2, null);
        if(relation1==null){
            relationInvolved.add(relation2);
        }else if(relation2==null) {
            relationInvolved.add(relation1);
        }else if(relation1.equals(relation2)){
            relationInvolved.add(relation1);
        }else{
            relationInvolved.add(relation1);
            relationInvolved.add(relation2);
        }
        return relationInvolved;
    }

    private static void complementComparison(List<Atom> body, HashMap<String, List<String>> subs, ComparisonAtom ca){
        if(!ca.getTerm1().isVariable()){
            ca.switchTerm();
        }
        String term1 = ca.getTerm1().toString();
        String term2 = ca.getTerm2().toString();
        boolean bothSub = ca.getTerm2().isVariable();
        List<String> firstSub = subs.getOrDefault(term1, new ArrayList<>());

        for(int i=0; i<firstSub.size(); i++){
            if(bothSub){
                List<String> secondSub = subs.getOrDefault(term2, new ArrayList<>());
                for(int j=0; j< secondSub.size(); j++){
                    body.add(new ComparisonAtom(new Variable(firstSub.get(i)), new Variable(secondSub.get(j)), ca.getOp()));
                }
            }else{
                body.add(new ComparisonAtom(new Variable(firstSub.get(i)), new Variable(term2), ca.getOp()));
            }
        }

    }
}
