package ed.inf.adbs.minibase.base;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Tuple {
    private int length;
    private List<Object> value;

    public Tuple(List<Object> value){
        this.value=value;
    }
    public int getLength() {
        return length;
    }

    public List<Object> getValue() {
        return value;
    }

}
