package ed.inf.adbs.minibase.base;

import java.util.Arrays;
import java.util.NoSuchElementException;

public enum ComparisonOperator {
    EQ("="),
    NEQ("!="),
    GT(">"),
    GEQ(">="),
    LT("<"),
    LEQ("<=");

    private final String text;

    ComparisonOperator(String text) {
        this.text = text;
    }

    @Override
    public String toString() {
        return text;
    }

    public static ComparisonOperator fromString(String s) throws NoSuchElementException {
        return Arrays.stream(values())
                .filter(op -> op.text.equalsIgnoreCase(s))
                .findFirst().get();
    }

    public boolean Compare(String term1, String term2) {
        int result = term1.compareTo(term2);
        switch (this){
            case EQ: return result==0;
            case NEQ: return result!=0;
            case GT: return result > 0;
            case LT: return result < 0;
            case GEQ: return result >= 0;
            case LEQ: return result <= 0;
            default: return false;
        }
    }
}
