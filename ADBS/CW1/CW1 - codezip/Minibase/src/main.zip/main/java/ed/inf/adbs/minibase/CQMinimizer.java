package ed.inf.adbs.minibase;

import ed.inf.adbs.minibase.base.*;
import ed.inf.adbs.minibase.parser.QueryParser;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.*;

/**
 *
 * Minimization of conjunctive queries
 *
 */
public class CQMinimizer {

    public static void main(String[] args) {

        if (args.length != 2) {
            System.err.println("Usage: CQMinimizer input_file output_file");
            return;
        }

        String inputFile = args[0];
        String outputFile = args[1];

        String input1 = "D:\\Edinburgh\\Sem2\\Sem2_note\\ADBS\\CW1\\CW1 - codezip\\Minibase\\data\\minimization\\input\\query1.txt";
        String input2 = "D:\\Edinburgh\\Sem2\\Sem2_note\\ADBS\\CW1\\CW1 - codezip\\Minibase\\data\\minimization\\input\\query2.txt";
        String input3 = "D:\\Edinburgh\\Sem2\\Sem2_note\\ADBS\\CW1\\CW1 - codezip\\Minibase\\data\\minimization\\input\\query3.txt";
        String input4 = "D:\\Edinburgh\\Sem2\\Sem2_note\\ADBS\\CW1\\CW1 - codezip\\Minibase\\data\\minimization\\input\\query4.txt";
        String input5 = "D:\\Edinburgh\\Sem2\\Sem2_note\\ADBS\\CW1\\CW1 - codezip\\Minibase\\data\\minimization\\input\\query5.txt";
        String input6 = "D:\\Edinburgh\\Sem2\\Sem2_note\\ADBS\\CW1\\CW1 - codezip\\Minibase\\data\\minimization\\input\\query6.txt";
        String input7 = "D:\\Edinburgh\\Sem2\\Sem2_note\\ADBS\\CW1\\CW1 - codezip\\Minibase\\data\\minimization\\input\\query7.txt";
        String input8 = "D:\\Edinburgh\\Sem2\\Sem2_note\\ADBS\\CW1\\CW1 - codezip\\Minibase\\data\\minimization\\input\\query8.txt";
        String input9 = "D:\\Edinburgh\\Sem2\\Sem2_note\\ADBS\\CW1\\CW1 - codezip\\Minibase\\data\\minimization\\input\\query9.txt";

        minimizeCQ(input1, outputFile);
        minimizeCQ(input2, outputFile);
        minimizeCQ(input3, outputFile);
        minimizeCQ(input4, outputFile);
        minimizeCQ(input5, outputFile);
        minimizeCQ(input6, outputFile);
        minimizeCQ(input7, outputFile);
        minimizeCQ(input8, outputFile);
        minimizeCQ(input9, outputFile);
//        minimizeCQ(inputFile, outputFile);
    }

    /**
     * CQ minimization procedure
     *
     * Assume the body of the query from inputFile has no comparison atoms
     * but could potentially have constants in its relational atoms.
     *
     */
    public static void minimizeCQ(String inputFile, String outputFile) {
        try{
            Query query = QueryParser.parse(Paths.get(inputFile));
            Head head = query.getHead();
            List<Variable> variables = head.getVariables();
            HashSet<String> criticalVar = new HashSet<>();
            for (Variable var: variables) {
                criticalVar.add(var.getName());
            }
            System.out.println(query);
            List<Atom> body = query.getBody();

            for (int i = 0; i < body.size(); i++) {
                for (int j = 0; j < body.size(); j++) {
                    if (i==j){
                        continue;
                    }
                    RelationalAtom thisAtom = (RelationalAtom) body.get(i);
                    RelationalAtom otherAtom = (RelationalAtom) body.get(j);
                    if(thisAtom.findMapping(otherAtom, criticalVar))
                        body.set(i, otherAtom);
                }
            }
            query.removeDuplicate();
            output(outputFile, query.toString());
            System.out.println(query);
            System.out.println();
        } catch (IOException ioe) {
            System.err.println("Exception occurred during parsing");
            ioe.printStackTrace();
        }


    }

    /**
     * Example method for getting started with the parser.
     * Reads CQ from a file and prints it to screen, then extracts Head and Body
     * from the query and prints them to screen.
     */

    public static void output(String outfile, String query){
        try{
            File file = new File(outfile);
            if(!file.exists()){
                file.createNewFile();
            }
            FileWriter writer = new FileWriter(file);
            BufferedWriter out = new BufferedWriter(writer);
            out.write(query);
            out.flush();
            out.close();
        }catch (IOException ioe){
            ioe.printStackTrace();
        }


    }

}
