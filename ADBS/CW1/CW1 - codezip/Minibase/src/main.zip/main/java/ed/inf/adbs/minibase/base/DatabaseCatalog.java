package ed.inf.adbs.minibase.base;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;

public class DatabaseCatalog {

    private final static DatabaseCatalog DATABASE_CATALOG = new DatabaseCatalog();

    private HashMap<String, Relation> relations;
    private DatabaseCatalog(){
        this.relations = new HashMap<>();
    }

    public static DatabaseCatalog getDatabaseCatalog() {
        return DATABASE_CATALOG;
    }

    private void addRelation(Relation relation) {
        this.relations.put(relation.getName(), relation);
    }

    public void initDatabase(String schema) {
        try{
            BufferedReader br = new BufferedReader(new FileReader(new File(schema)));
            String lineContent;
            while((lineContent=br.readLine())!=null){
                String[] content = lineContent.split(" ");
                addRelation(new Relation(content[0], Arrays.copyOfRange(content, 1, content.length)));
            }
        }catch(IOException ioe) {
            ioe.printStackTrace();
        }
    }

    public Relation getRelation(String relationName) {
        return this.relations.get(relationName);
    }

    public HashMap<String, Relation> getRelations(){
        return relations;
    }
}
