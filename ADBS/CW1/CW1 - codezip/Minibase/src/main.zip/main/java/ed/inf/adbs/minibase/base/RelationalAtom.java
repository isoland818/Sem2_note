package ed.inf.adbs.minibase.base;

import ed.inf.adbs.minibase.Utils;

import java.util.*;

public class RelationalAtom extends Atom {
    private String name;

    private List<Term> terms;

    public RelationalAtom(String name, List<Term> terms) {
        this.name = name;
        this.terms = terms;
    }

    public String getName() {
        return name;
    }

    public List<Term> getTerms() {
        return terms;
    }


    public void setTerm(int index, Term term){
        this.terms.set(index, term);
    }

    public boolean findMapping(RelationalAtom otherAtom, HashSet<String> criticalVar){
        if (!this.getName().equals(otherAtom.getName())){
            return false;
        }else{
            for (int i = 0; i < this.getTerms().size(); i++) {
                if (this.getTerms().get(i).isVariable()) {
                    Variable thisVar = (Variable) this.getTerms().get(i);
                    Term otherTerm = otherAtom.getTerms().get(i);
                    if (criticalVar.contains(thisVar.getName()) && !otherTerm.equals(thisVar)) {
                        return false;
                    }
                } else {
                    Constant thisConst = (Constant) this.getTerms().get(i);
                    Term otherTerm = otherAtom.getTerms().get(i);
                    if(!thisConst.equals(otherTerm)) {
                        return false;
                    }
                }
            }
            return true;
        }
    }

    @Override
    public String toString() {
        return name + "(" + Utils.join(terms, ", ") + ")";
    }
}
