package ed.inf.adbs.minibase.base;

import ed.inf.adbs.minibase.Utils;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

public class Query {
    private Head head;

    private List<Atom> body;

    public Query(Head head, List<Atom> body) {
        this.head = head;
        this.body = body;
    }

    public Head getHead() {
        return head;
    }

    public List<Atom> getBody() {
        return body;
    }

    @Override
    public String toString() {
        return head + " :- " + Utils.join(body, ", ");
    }

    public void removeDuplicate() {
        HashSet<String> uniqueAtom = new HashSet<>();
        Iterator<Atom> atomIterator = this.getBody().listIterator();
        while(atomIterator.hasNext()){
            String curAtom = atomIterator.next().toString();
            if(uniqueAtom.contains(curAtom)){
                atomIterator.remove();
            }else{
                uniqueAtom.add(curAtom);
            }
        }
    }
}
