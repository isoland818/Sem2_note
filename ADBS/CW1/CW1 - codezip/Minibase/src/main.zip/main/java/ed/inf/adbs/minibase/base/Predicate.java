package ed.inf.adbs.minibase.base;

import java.util.HashMap;
import java.util.List;

public class Predicate {

    public static boolean check(Tuple tuple, List<ComparisonAtom> conditions, HashMap<String, Integer> reference) {
        if (conditions==null){
            return true;
        }
        for(ComparisonAtom atom: conditions) {
            Term term1 = atom.getTerm1();
            Term term2 = atom.getTerm2();
            String termStr1 = term1.isVariable()? tuple.getValue().get(reference.get(term1.toString())).toString() : term1.toString();
            String termStr2 = term2.isVariable()? tuple.getValue().get(reference.get(term2.toString())).toString() : term2.toString();
            if(!atom.getOp().Compare(termStr1, termStr2)){
                return false;
            }
        }
        return true;
    }

    public static Tuple join(Tuple outer, Tuple inner, List<ComparisonAtom> conditions, HashMap<String, Integer> outerRefer, HashMap<String, Integer> innerRefer) {
        for(ComparisonAtom atom: conditions) {
            String term1 = atom.getTerm1().toString();
            String term2 = atom.getTerm2().toString();
            String termStr1 = innerRefer.containsKey(term1)? inner.getValue().get(innerRefer.get(term1)).toString(): outer.getValue().get(outerRefer.get(term1)).toString();

        }
        return null;
    }
}
