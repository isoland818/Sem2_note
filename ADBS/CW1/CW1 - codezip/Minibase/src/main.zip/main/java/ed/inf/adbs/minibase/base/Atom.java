package ed.inf.adbs.minibase.base;

public class Atom {
    @Override
    public boolean equals(Object obj) {
        return this.toString().equals(obj.toString());
    }

    public boolean isRelational(){
        try{
            this.getClass().asSubclass(RelationalAtom.class);
            return true;
        }catch (ClassCastException e) {
            return false;
        }
    }
}

