package ed.inf.adbs.minibase.base;



import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public class ScanOperator implements Operator {

    DatabaseCatalog databaseCatalog = DatabaseCatalog.getDatabaseCatalog();

    private RelationalAtom atom;
    private Relation relation;
    private List<Tuple> tuples;
    private Iterator<Tuple> scanIterator;

    private HashMap<String, Integer> reference;

    public ScanOperator(RelationalAtom atom) {
        this.relation = databaseCatalog.getRelation(atom.getName());
        this.atom=atom;
        this.tuples = readRelation(this.relation);
        this.scanIterator = tuples.listIterator();
        initReference();
    }

    private void initReference(){
        reference = new HashMap<>();
        List<Term> terms = atom.getTerms();
        for (int i = 0; i < terms.size(); i++) {
            reference.put(terms.get(i).toString(), i);
        }
    }
    public RelationalAtom getAtom() {
        return atom;
    }

    public HashMap<String, Integer> getReference() {
        return reference;
    }

    public List<Tuple> readRelation(Relation relation) {
        List<Tuple> tuples = new ArrayList<>();
        String file = relation.getFile();
        String[] schema = relation.getSchema();
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;
            while((line=br.readLine())!=null) {
                String[] content = line.split(", ");
                List<Object> value = new ArrayList<>();
                for (int i = 0; i < content.length; i++) {
                    value.add(parseValue(schema[i], content[i]));
                }
                tuples.add(new Tuple(value));
            }
            return tuples;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return tuples;
    }
    @Override
    public Tuple getNextTuple() {
        if(scanIterator.hasNext()){
            return scanIterator.next();
        }else{
            return null;
        }
    }

    @Override
    public void reset() {
        this.scanIterator = tuples.listIterator();
    }

    @Override
    public void dump() {

    }

    public Object parseValue(String type, String origin) {
        switch (type) {
            case "int": return Integer.parseInt(origin);
            case "string": return origin;
            default: return null;
        }
    }
}
