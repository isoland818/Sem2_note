package ed.inf.adbs.minibase.base;

import java.util.List;

public class Relation {
    private String file;
    private String name;
    private String[] schema;

    public Relation(String name, String[] schema){
        this.name = name;
        this.schema = schema;
        this.file="D:\\Edinburgh\\Sem2\\Sem2_note\\ADBS\\CW1\\CW1 - codezip\\Minibase\\data\\evaluation\\db\\files\\"+name+".csv";
    }

    public String[] getSchema() {
        return schema;
    }

    public String getName() {
        return name;
    }

    public String getFile() {
        return file;
    }
}
