package ed.inf.adbs.minibase.base;

public class Term {

    public boolean isVariable(){
        try{
            this.getClass().asSubclass(Variable.class);
            return true;
        }catch (ClassCastException e) {
            return false;
        }
    }

    @Override
    public boolean equals(Object obj) {
        return this.toString().equals(obj.toString());
    }
}


