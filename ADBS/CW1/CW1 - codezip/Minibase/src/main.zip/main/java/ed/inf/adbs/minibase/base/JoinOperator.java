package ed.inf.adbs.minibase.base;

import java.util.*;

public class JoinOperator implements Operator{

    private Operator left;
    private Operator right;

    private HashMap<String, Integer> reference;

    private List<Tuple> tuples;

    private Iterator<Tuple> joinIterator;

    private List<ComparisonAtom> joinConditions;

    public JoinOperator(Operator left, Operator right, List<ComparisonAtom> joinConditions){
        this.left=left;
        this.right=right;
        this.joinConditions=joinConditions;
        initReference();
        this.tuples=join();
        this.joinIterator=tuples.listIterator();
    }
    @Override
    public Tuple getNextTuple() {
        if(joinIterator.hasNext()){
            return joinIterator.next();
        }
        return null;
    }

    private List<Tuple> join() {
        Tuple outer;
        Tuple inner;
        List<Tuple> tuples = new ArrayList<>();
        while((outer=left.getNextTuple())!=null){
            List<ComparisonAtom> resolvedConditions = resolveOuter(left.getReference(), outer);
            while((inner=right.getNextTuple())!=null){
                if(Predicate.check(inner, resolvedConditions, right.getReference())){
                    List<Object> newTuple = new ArrayList<>(outer.getValue());
                    newTuple.addAll(inner.getValue());
                    tuples.add(new Tuple(newTuple));
                }
            }
        }
        return tuples;
    }

    public List<ComparisonAtom> resolveOuter(HashMap<String, Integer> reference, Tuple outer){
        List<ComparisonAtom> resolvedCondition = new ArrayList<>(joinConditions);
        for (ComparisonAtom atom: resolvedCondition){
            String term1 = atom.getTerm1().toString();
            String term2 = atom.getTerm2().toString();
            if(reference.containsKey(term1)){
                atom.setTerm1(new StringConstant(outer.getValue().get(reference.get(term1)).toString()));
            }
            if(reference.containsKey(term2)){
                atom.setTerm2(new StringConstant(outer.getValue().get(reference.get(term2)).toString()));
            }
        }
        return resolvedCondition;
    }

    @Override
    public void reset() {
        this.joinIterator=tuples.listIterator();
    }

    @Override
    public void dump() {

    }

    @Override
    public HashMap<String, Integer> getReference() {
        return reference;
    }

    public void initReference() {
        HashMap<String, Integer> rightRef = right.getReference();
        HashMap<String, Integer> reference = new HashMap<>(left.getReference());
        int count = reference.size();
        for(String key: rightRef.keySet()){
            int newIndex = rightRef.get(key)+count;
            if(!reference.containsKey(key)){
                reference.put(key, newIndex);
            }else{
                reference.put("inner."+key, count);
            }
        }
        this.reference = reference;
    }
}
